#include "funkcja.h"
