import java.lang.reflect.InvocationTargetException;

public class Węzeł<T extends Comparable<T> & Dodawalny<T>> extends WęzełAbstrakcyjny<T>
{
    private T klucz;
    private WęzełAbstrakcyjny<T> lewy;
    private WęzełAbstrakcyjny<T> prawy;

    public Węzeł(T klucz, Wartownik<T> wartownik)
    {
        this.klucz = klucz;
        this.lewy = wartownik;
        this.prawy = wartownik;
    }

    @Override
    public WęzełAbstrakcyjny<T> wstaw(T klucz, Wartownik<T> wartownik)
    {
        if (klucz.compareTo(this.klucz) <= 0)
        {
            lewy = lewy.wstaw(klucz, wartownik);
        }
        else
        {
            prawy = prawy.wstaw(klucz, wartownik);
        }

        return this;
    }

    @Override
    public Węzeł<T> znajdź(T klucz)
    {
        int wynikPorównania = klucz.compareTo(this.klucz);

        if (wynikPorównania < 0)
        {
            return lewy.znajdź(klucz);
        }
        else if (wynikPorównania == 0)
        {
            return this;
        }
        else
        {
            return prawy.znajdź(klucz);
        }
    }

    @Override
    public int rozmiar()
    {
        return lewy.rozmiar() + 1 + prawy.rozmiar();
    }

    @Override
    public int wysokość()
    {
        return Math.max(lewy.wysokość(), prawy.wysokość()) + 1;
    }

    @Override
    public T suma(Class<T> typ) throws NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException
    {
        return lewy.suma(typ).dodaj(klucz).dodaj(prawy.suma(typ));
    }

    @Override
    public void drukujWLinii()
    {
        lewy.drukujWLinii();
        System.out.print(" " + klucz + " ");
        prawy.drukujWLinii();
    }

    @Override
    public void drukujDrzewo(int rozmiarWcięcia, int przesunięcie)
    {
        prawy.drukujDrzewo(rozmiarWcięcia, przesunięcie + rozmiarWcięcia);
        System.out.println(" ".repeat(przesunięcie) + klucz);
        lewy.drukujDrzewo(rozmiarWcięcia, przesunięcie + rozmiarWcięcia);
    }

    @Override
    public T klucz() {
        return klucz;
    }

    public String toString()
    {
        return "Węzeł z wartością " + klucz.toString();
    }
}
